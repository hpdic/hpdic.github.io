#coding: utf-8
import time
import numpy as np
from os import path
from os import remove
from memory_profiler import memory_usage


'''

## import  
from .ProfielTime import profileMemAndTime

## usage
profileMemAndTime()

'''


## file will be removed, if exist and clearOld
def openOutFile(destFile, removeOld=False):

    ## if exist, remove it
    if (path.exists(destFile)) and removeOld:
        remove(destFile)

    if (path.exists(destFile)):
        outfile = open(destFile, 'a')
    else:
        outfile = open(destFile, 'w')

    return outfile


def writeLines(logFile, lines):
    outFile = openOutFile(logFile, False)
    outFile.writelines(lines)
    outFile.close()
    pass


class ProfileTimeKit:
    def __init__(self, logFile):
        self.logFile = logFile      ## output
        self.start = time.time()    ## begining
        self.pre = self.start

        if (path.exists(logFile)):
            remove(logFile)

        writeLines(logFile, "second,run,mem,time\n")
        pass

    def profile(self):
        curTime = time.time()
        second = round(curTime - self.start, 2)
        run = round(curTime - self.pre, 2)
        time_stamp = time.strftime("%H:%M:%S")

        mem = memory_usage(-1, timeout=None)[0]

        lines = "{0},{1},{2},{3}\n".format(second, run, mem, time_stamp)
        writeLines(self.logFile, lines)

        self.pre = curTime
        pass


profileKit = ProfileTimeKit("time_sec.txt")


def profileMemAndTime():
    profileKit.profile()
    pass


if __name__ == '__main__':
    for i in range(10):
        time.sleep(1)
        profileMemAndTime()
    pass
