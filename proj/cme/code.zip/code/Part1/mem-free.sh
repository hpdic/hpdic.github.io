#!/bin/bash

# $1: seconds to sleep between reads
# $2: amount of time to monitor (minutes)

# usage: bash mem-monitor-ubuntu.sh 1 1

START=$(date +%s)
let repeats=$2*60

count=0
seconds=0

mem_used=0.0
swap_used=0.0

sn=1


## fetch total memory
## total=$(free -m | awk "{ if( \$1 ~ /"^Mem:"/ ) { print \$2 } }" | bc)

## fetch total swap memory
## swap_total=$(free -m | awk "{ if( \$1 ~ /"^Swap:"/ ) { print \$2 } }" | bc)

## echo "mem-total: $total"
## echo "swap-total: $swap_total"


echo "count      seconds      mem-used      swap-used      date_ns"

while [ $seconds -lt $repeats ]
do
    sleep $1

    mem_used=0.0
    swap_used=0.0

    sn=1

    date_ns=$(date '+%Y-%m-%d %H:%M:%S %N')

    for output in $(free -m | awk "{ if( \$2 ~ /[0-9]/ ) { print \$3 } }" | bc)
    do
        if [ $sn -eq 2 ] ; then
            swap_used=$( echo "scale=2;${output}" | bc )
            let sn=1
        else
            mem_used=$( echo "scale=2;${output}" | bc )
            let sn=2
        fi
    done

    seconds=$(date +%s)
    let seconds-=START
    let count+=1

    echo "$count      $seconds      $mem_used      $swap_used      $date_ns"
done
