#!/bin/bash
# $1: name of process to monitor , such as python, docker, java

# usage: bash cur-mem.sh python

## fetch total memory
total=$(free -m | awk "{ if( \$1 ~ /"^Mem:"/ ) { print \$2 } }" | bc)

process=$1
all_usage=0
memused=0
unset memused

for output in $(top -b -n 1 | awk "{ if ( ( \$1 ~ /[0-9]/ ) && ( \$10 > 0.00 ) ) { print \$10, \$12 }}")
do
    if [ $memused ] ; then
        if [ $( echo $output | grep -c "^.*${process}.*" |bc) -gt 0 ] ; then
            all_usage=$( echo "scale=2;${memused}+${all_usage}" | bc )
        fi
        unset memused
    else
        memused=$output
    fi
done

all_usage=$( echo "scale=2;${all_usage}*${total}/200" | bc )
#all_usage=$( echo "scale=2;${all_usage}*${total}/100" | bc )

echo "$all_usage"
