# coding:utf-8

import dipy.tracking.life as life
import nibabel as nib
import numpy as np
# from stanford import hardi_data
from dipy.data import fetch_stanford_hardi
from dipy.data import read_stanford_labels
import time
from os import path
from os import remove
from memory_profiler import memory_usage

import threading
import numpy as np
from scipy.optimize import leastsq


## ----------------------- write log -----------------------

## file will be removed, if exist and clearOld
def openOutFile(destFile, removeOld=False):

    ## if exist, remove it
    if (path.exists(destFile)) and removeOld:
        remove(destFile)

    if (path.exists(destFile)):
        outfile = open(destFile, 'a')
    else:
        outfile = open(destFile, 'w')

    return outfile


def writeLines(filepath, lines):
    outFile = openOutFile(filepath, False)
    outFile.writelines(lines)
    outFile.close()
    pass


## ----------------------- func 1 -----------------------


## y = k * x + b
def func1(p,x):
    k,b=p
    return k*x+b


def error1(p,x,y):
    return func1(p,x)-y


def prediction1(X,Y):
    
    Xi = np.array(X)
    Yi = np.array(Y)


    p0=[1,0]


    Para=leastsq(error1,p0,args=(Xi,Yi))
    k,b=Para[0]
    # x = np.linspace(0, 10, 1000)
    x = Xi[-1] + 1
    y = k * x + b
    return round(y,2)

def pred_demo1():
    X = [8.19, 2.72, 6.39, 8.71, 4.7, 2.66, 3.78]
    Y = [7.01, 2.78, 6.47, 6.71, 4.1, 4.23, 4.05]
    print("y=", prediction1(X, Y))
    pass


## ----------------------- func 2 -----------------------


## y = a*x^2 + b*x + c
def func2(p,x):
   a,b,c=p
   return a*x**2+b*x+c

## error
def error2(p,x,y):
    return func2(p,x)-y


### y = a*x^2 + b*x + c
def prediction2(X,Y):
    
    Xi = np.array(X)
    Yi = np.array(Y)


    p0=[1,1,0]

    Para=leastsq(error2,p0,args=(Xi,Yi))
    a, b, c = Para[0]
    # x = np.linspace(0, 10, 1000)
    x = Xi[-1] + 1
    y = a * x ** 2 + b * x + c
    return round(y,2)

def pred_demo2():
    X = [0, 1, 2, 3, -1, -2, -3]
    Y = [-1.21, 1.9, 3.2, 10.3, 2.2, 3.71, 8.7]
    print("y=", prediction2(X, Y))
    pass

## ----------------------- func 3 -----------------------


## y = a*x^3 + b*x^2 + c*x + d
def func3(p,x):
   a,b,c,d=p
   return a*x**3+b*x**2+c*x+d

## error
def error3(p,x,y):
    return func3(p,x)-y


def prediction3(X,Y):
    
    Xi = np.array(X)
    Yi = np.array(Y)


    p0=[1,1,1,0]


    Para=leastsq(error3,p0,args=(Xi,Yi))
    a, b, c, d= Para[0]
    x = Xi[-1] + 1
    y = a * x ** 3 + b * x ** 2 + c * x + d
    return round(y,2)

def pred_demo3():
    X = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    Y = [1, 10, 31, 70, 133, 226, 355, 526, 745, 1018]
    print("y=", prediction3(X, Y))


## ----------------------- profiling -----------------------

class ProfileKit:
    def __init__(self, powerL, fitN, logFile):
        self.pL = powerL
        self.fN = fitN
        self.logFile = logFile
        self.X = []
        self.Y = []
        if self.pL <= 1:
            self.pL = 1
            self.predFunc = prediction1
        if self.pL == 2:
            self.predFunc = prediction2
        else: ## self.powerL >= 3
            self.pL = 3
            self.predFunc = prediction3

        if (path.exists(logFile)):
            remove(logFile)
        writeLines(logFile, "second,run,mem,pred,time\n")

    def profile(self, start, pre, mem):
        '''
        :param start: profiling time
        :param pre: last profiling time
        :param mem: memory usage
        :return:
        '''
        second = round(time.time() - start, 2)
        run = round(time.time() - pre, 2)
        time_stamp = time.strftime("%H:%M:%S")

        self.X.append(second)
        self.Y.append(mem)

        xLen = len(self.X)
        if xLen < 2:
            pred = mem
        elif xLen >= (self.pL + 1):
            pred = self.predFunc(self.X, self.Y)
            if xLen >= self.fN:
                self.X = self.X[1:]
                self.Y = self.Y[1:]
        else:
            if xLen < 3:
                pred = prediction1(self.X, self.Y)
            elif xLen < 5:
                pred = prediction2(self.X, self.Y)
            else:
                pred = prediction3(self.X, self.Y)

        writeLines(self.logFile, "{0},{1},{2},{3},{4}\n".format(second, run, round(mem, 2), pred, time_stamp))
        pass
    pass


## ----------------------- thread -----------------------

DIPY_END = False

def profileV2Loop():
    start = time.time()
    pre = start

    p1f2 = ProfileKit(powerL=1, fitN=2, logFile="power1_fit2.txt")
    p2f3 = ProfileKit(powerL=2, fitN=3, logFile="power2_fit3.txt")
    p3f5 = ProfileKit(powerL=3, fitN=5, logFile="power3_fit5.txt")

    while not DIPY_END:
        time.sleep(1)
        mem = memory_usage(-1, timeout=None)[0]

        p1f2.profile(start, pre, mem)
        p2f3.profile(start, pre, mem)
        p3f5.profile(start, pre, mem)

        pre = time.time()
    pass

def profilingThread():
    t1 = threading.Thread(target=profileV2Loop)
    t1.start()
    pass


## ----------------------- memusage -----------------------

full_File = "run_memV6.txt"
sec_File = "run_secV6.txt"


def memusage():
    global DIPY_END

    start = time.time()
    pre = start
    p1f3 = ProfileKit(powerL=1, fitN=3, logFile=sec_File)

    hardi_img, gtab, labels_img = read_stanford_labels()
    data = hardi_img.get_data()
    fiber_model = life.FiberModel(gtab)
    candidate_sl = [s[0] for s in nib.trackvis.read('./probabilistic_724_1_sphere.trk', points_space='voxel')[0]]

    loops = len(candidate_sl)
    print("candidate_sl: %s" % loops)

    for i in np.arange(0, 19):
        this = 2 ** i
        fiber_model.fit(data, candidate_sl[:this], affine=np.eye(4))

        mem = memory_usage(-1, timeout=None)[0]
        p1f3.profile(start, pre, mem)

        print("Number of streamlines: {0}, mem: {1}".format(this, mem))
        if this > loops:
            break
        pre=time.time()
    DIPY_END = True
    pass


if __name__ == '__main__':
    profilingThread()
    memusage()
    pass

