#/usr/bin/env bash


container_id=$(docker run -d --name DipyLife python2.7:dipylife)
save_path=/tmp/$container_id/checkpoints

if [ -z "$container_id" ]; then
   echo "   "
   echo "-------------------------------------"
   echo "container_id is empty, please check!!"
   exit 1
fi

echo "container_id:${container_id}"
echo "save_path:${save_path}"


START=$(date +%s)
seconds=0

## fetch total memory
total=$(free -m | awk "{ if( \$1 ~ /"^Mem:"/ ) { print \$2 } }" | bc)
echo "total memory: ${total}"

## max use of memory
max_mem=$( echo "scale=2;${total}*0.9" | bc )

process="python"
#process="docker"
pre_mem="$(bash cur-mem.sh ${process})"
echo "current ${process} memory: $pre_mem"

cur_mem=0
pred=0
max_second=60

## save the predicted time
predfile="pred_mem.txt"
rm $predfile

echo "second    use/total    pred"
echo "second    use/total    pred" >> $predfile


while [ $( echo "$pred < $max_mem" | bc ) -eq 1 ]
do
   sleep 1;

   let second=$(date +%s)-START

   if [ $second -gt $max_second ] ; then
      bash clear-container.sh
      exit 0
   fi

   cur_mem="$(bash cur-mem.sh ${process})"
   pred=$( echo "scale=2;${cur_mem}*2-${pre_mem}" | bc )
   pre_mem=$( echo "scale=2;${cur_mem}" | bc )
   echo "$second    ${cur_mem}/${max_mem}    ${pred}"
   echo "$second    ${cur_mem}/${max_mem}    ${pred}" >> $predfile
done

CKPOINT=$(date +%s)
let ck_sec=$(date +%s)-START
point="checkpoint${ck_sec}";
cpoint=$(docker checkpoint create --checkpoint-dir=/tmp DipyLife $point;)

if [ "$cpoint" != "$point" ] ; then
   echo "   "
   echo "---------------------------------"
   echo "create checkpoint: $point failed!"
   bash clear-container.sh
   exit 1
fi


## save all info
filename="checkpoint.txt"
rm $filename
echo "$save_path" >> $filename
echo "$point" >> $filename
echo "DipyLife" >> $filename
echo "$process" >> $filename


## if go on restoring
if read -t 20 -p "restore ${point} (y/N)?:" name ; then

   if [ "$name" == "Y" -o "$name" == "y" ] ; then
      echo "restore ${point} ..."
      docker start --checkpoint-dir=$save_path --checkpoint=$point DipyLife;

      let second=$(date +%s)-START
      date_ns=$(date '+%Y-%m-%d %H:%M:%S %N')
      echo "restore ${point}, ${second} seconds, $date_ns";

      let gap=$(date +%s)-CKPOINT
      let run_sec=second-gap
      pre_mem="$(bash cur-mem.sh ${process})"

      while [ $run_sec -lt $max_second ]
      do
         sleep 1;
         let second=$(date +%s)-START
         let run_sec=second-gap

         cur_mem="$(bash cur-mem.sh ${process})"
         pred=$( echo "scale=2;${cur_mem}*2-${pre_mem}" | bc )
         pre_mem=$( echo "scale=2;${cur_mem}" | bc )
         echo "$run_sec    ${cur_mem}/${total}    ${pred}"
      done
   fi
fi

## clear container
bash clear-container.sh

## clear checkpoint 
echo "  "
echo "----------------- clear checkpoint ----------------------"
if read -t 20 -p "clear checkpoint ${point} (y/N)?:" name ; then
   if [ "$name" == "Y" -o "$name" == "y" ] ; then
      sudo rm -rf $save_path
      sudo rm -rf /tmp/$container_id
   fi
fi




