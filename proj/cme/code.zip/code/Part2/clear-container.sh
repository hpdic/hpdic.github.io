#!/bin/bash

echo "   ";
echo "------------------------------------------"
echo "run result of DipyLife:"

docker logs DipyLife;

echo "   ";
echo "------------------------------------------"
echo "copy run result from DipyLife Container..."

docker stop DipyLife;

## copy result to current path
docker cp DipyLife:/life/  ./
docker system prune;

