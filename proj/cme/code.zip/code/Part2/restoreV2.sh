#/usr/bin/env bash

save_path=""
point=""
container=""
process="docker"
filename="checkpoint.txt"

sn=1
while read LINE
do
   if [ $sn -eq 1 ] ; then
      save_path=$LINE
   elif [ $sn -eq 2 ] ; then
      point=$LINE
   elif [ $sn -eq 3 ] ; then
      container=$LINE
   elif [ $sn -eq 4 ] ; then
      process=$LINE
   fi

   let sn+=1

done < $filename


if [ -z "$save_path" -o -z "$point" -o -z "$container" ]; then
   echo "   "
   echo "-------------------------------------"
   echo "save path, checkpoint or container info is miss, please check!!"
   exit 1
fi


max_second=60
echo "path: $save_path"
echo "checkpoint:  $point"
echo "container: $container"
echo "process: $process"


## fetch total memory
total=$(free -m | awk "{ if( \$1 ~ /"^Mem:"/ ) { print \$2 } }" | bc)
echo "total memory: ${total}"

## max use of memory
max_mem=$( echo "scale=2;${total}*0.2" | bc )


if read -t 10 -p "restore ${point} (y/N)?:" name ; then

   if [ "$name" == "Y" -o "$name" == "y" ] ; then
      START=$(date +%s)
      second=0
      echo "restore ${point} ..."
      docker start --checkpoint-dir=$save_path --checkpoint=$point $container;

      let second=$(date +%s)-START
      date_ns=$(date '+%Y-%m-%d %H:%M:%S %N')
      echo "restore ${point}, ${second} seconds, $date_ns";

      pre_mem="$(bash cur-mem.sh ${process})"

      echo "-------------------------------------"
      echo "second    use/total    pred"

      while [ $second -lt $max_second ]
      do
         sleep 1;
         let second=$(date +%s)-START

         cur_mem="$(bash cur-mem.sh ${process})"
         pred=$( echo "scale=2;${cur_mem}*2-${pre_mem}" | bc )
         pre_mem=$( echo "scale=2;${cur_mem}" | bc )
         echo "$second    ${cur_mem}/${total}    ${pred}"

         if [ $( echo "$pred < $max_mem" | bc ) -eq 1 ] ; then
            continue
         fi

         let ck_sec=$(date +%s)-START
         point="checkpoint${ck_sec}";
         cpoint=$(docker checkpoint create --checkpoint-dir=/tmp DipyLife $point;)

         if [ "$cpoint" != "$point" ] ; then
            echo "   "
            echo "---------------------------------"
            echo "create checkpoint: $point failed!"
            bash clear-container.sh
            exit 1
         fi

         echo "create ${point}, ${ck_sec} seconds;

         ## saving info
         filename="checkpoint.txt"
         rm $filename
         echo "$save_path" >> $filename
         echo "$point" >> $filename
         echo "DipyLife" >> $filename
         echo "$process" >> $filename

         break

      done
   fi
fi

bash clear-container.sh


